package com.sk27.db_crud

class StudentListModel {
    var id: Int = 0
    var sName: String = ""
    var sClass: String = ""
    var sAddress: String = ""
}